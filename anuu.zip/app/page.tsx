"use client"

import { useState } from "react"
import { RouteInput } from "@/components/route-input"
import { RouteCard } from "@/components/route-card"
import { StatsCard } from "@/components/stats-card"
import { Leaf, TrendingDown, Fuel, Route as RouteIcon, TreePine, Sparkles } from "lucide-react"

interface RouteData {
  id: string
  name: string
  distance: string
  duration: string
  fuel: string
  co2: string
  isBestEco: boolean
}

const mockRoutes: RouteData[] = [
  {
    id: "1",
    name: "Highway Express",
    distance: "142.5 km",
    duration: "1h 45min",
    fuel: "12.8 L",
    co2: "29.4 kg",
    isBestEco: false,
  },
  {
    id: "2",
    name: "Scenic Eco Route",
    distance: "156.2 km",
    duration: "2h 10min",
    fuel: "9.2 L",
    co2: "21.2 kg",
    isBestEco: true,
  },
  {
    id: "3",
    name: "City Bypass",
    distance: "138.9 km",
    duration: "2h 05min",
    fuel: "11.5 L",
    co2: "26.5 kg",
    isBestEco: false,
  },
]

export default function EcoRouteOptimizer() {
  const [source, setSource] = useState("")
  const [destination, setDestination] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [routes, setRoutes] = useState<RouteData[]>([])
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null)
  const [showResults, setShowResults] = useState(false)

  const handleFindRoutes = async () => {
    setIsLoading(true)
    setShowResults(false)
    
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    setRoutes(mockRoutes)
    setSelectedRoute(mockRoutes.find((r) => r.isBestEco)?.id || null)
    setShowResults(true)
    setIsLoading(false)
  }

  const co2Saved = showResults ? "8.2 kg" : "—"
  const fuelSaved = showResults ? "3.6 L" : "—"
  const treesEquivalent = showResults ? "0.4" : "—"

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-gradient-to-br from-primary/20 to-accent/20">
                <Leaf className="h-6 w-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-foreground">Eco Route Optimizer</h1>
                <p className="text-xs text-muted-foreground">Find greener paths, reduce your footprint</p>
              </div>
            </div>
            <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>AI-Powered Analysis</span>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Input Section */}
        <section>
          <RouteInput
            source={source}
            destination={destination}
            onSourceChange={setSource}
            onDestinationChange={setDestination}
            onFindRoutes={handleFindRoutes}
            isLoading={isLoading}
          />
        </section>

        {/* Stats Overview */}
        <section>
          <div className="flex items-center gap-2 mb-4">
            <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
              {showResults ? "Savings Summary" : "Potential Savings"}
            </h2>
            {showResults && (
              <span className="px-2 py-0.5 text-xs bg-primary/20 text-primary rounded-full">
                Best Route Selected
              </span>
            )}
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <StatsCard
              title="CO2 Saved"
              value={co2Saved}
              subtitle={showResults ? "vs average route" : "Enter route to calculate"}
              icon={TrendingDown}
              highlight={showResults}
            />
            <StatsCard
              title="Fuel Saved"
              value={fuelSaved}
              subtitle={showResults ? "vs average route" : "Enter route to calculate"}
              icon={Fuel}
              highlight={showResults}
            />
            <StatsCard
              title="Trees Equivalent"
              value={treesEquivalent}
              subtitle={showResults ? "trees planted per trip" : "Enter route to calculate"}
              icon={TreePine}
              highlight={showResults}
            />
          </div>
        </section>

        {/* Routes Section */}
        {showResults && (
          <section className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center gap-2 mb-4">
              <RouteIcon className="h-4 w-4 text-muted-foreground" />
              <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                Available Routes
              </h2>
              <span className="text-xs text-muted-foreground">({routes.length} found)</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {routes.map((route) => (
                <RouteCard
                  key={route.id}
                  routeName={route.name}
                  distance={route.distance}
                  duration={route.duration}
                  fuel={route.fuel}
                  co2={route.co2}
                  isBestEco={route.isBestEco}
                  isSelected={selectedRoute === route.id}
                  onClick={() => setSelectedRoute(route.id)}
                />
              ))}
            </div>
          </section>
        )}

        {/* Empty State */}
        {!showResults && !isLoading && (
          <section className="text-center py-16">
            <div className="inline-flex items-center justify-center p-4 rounded-full bg-secondary mb-4">
              <RouteIcon className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-2">Ready to optimize your route</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Enter your source and destination above to discover eco-friendly routes that save fuel and reduce CO2 emissions.
            </p>
          </section>
        )}

        {/* Loading State */}
        {isLoading && (
          <section className="text-center py-16 animate-pulse">
            <div className="inline-flex items-center justify-center p-4 rounded-full bg-primary/20 mb-4">
              <Leaf className="h-8 w-8 text-primary animate-spin" />
            </div>
            <h3 className="text-lg font-medium text-foreground mb-2">Analyzing routes...</h3>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Our AI is calculating the most eco-friendly paths for your journey.
            </p>
          </section>
        )}
      </div>

      {/* Footer */}
      <footer className="border-t border-border mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Leaf className="h-3 w-3 text-primary" />
              <span>Making transportation greener, one route at a time</span>
            </div>
            <div className="flex items-center gap-4">
              <span>Data powered by eco-analytics</span>
            </div>
          </div>
        </div>
      </footer>
    </main>
  )
}
